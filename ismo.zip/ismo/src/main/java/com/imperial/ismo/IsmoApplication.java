package com.imperial.ismo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IsmoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IsmoApplication.class, args);
	}

}
